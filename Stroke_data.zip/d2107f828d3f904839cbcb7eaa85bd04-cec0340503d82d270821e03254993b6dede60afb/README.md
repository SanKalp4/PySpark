Dataset Source: [Healthcare Dataset Stroke Data](https://www.kaggle.com/asaumya/healthcare-dataset-stroke-data) from Kaggle.

This dataset is used to predict whether a patient is likely to get stroke based on the input parameters like gender, age, and various diseases and smoking status. A subset of the original train data is taken using the filtering method for Machine Learning and Data Visualization purposes.


About the Data: 
Each row in the data provides relavant information about a person , for instance; age, gender,smoking status, occurance of stroke in addition to other information
Unknown in Smoking status means the information is unavailable.
N/A in other input fields imply that it is not applicable.

